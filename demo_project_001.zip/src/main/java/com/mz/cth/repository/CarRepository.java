package com.mz.cth.repository;

import org.springframework.data.repository.CrudRepository;

import com.mz.cth.model.Car;

public interface CarRepository extends CrudRepository<Car,String>{
Car findById(long id);
}
