package com.mz.cth.repository;

import org.springframework.data.repository.CrudRepository;

import com.mz.cth.model.Owner;

public interface OwnerRepository extends CrudRepository<Owner, String> {
	Owner findById(long id); // Para procura de um elemento por codigo

}
