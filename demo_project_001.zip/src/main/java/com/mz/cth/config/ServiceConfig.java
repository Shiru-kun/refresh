package com.mz.cth.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mz.cth.service")
public class ServiceConfig {

}
